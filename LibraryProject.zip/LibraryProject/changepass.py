#!C:\Users\DELL\AppData\Local\Programs\Python\Python310\python
import cgi
import pymysql

print("Content-type:text/html")
print()

req=cgi.FieldStorage()
id=req.getvalue("uid")
cur=req.getvalue("cur")
nwp=req.getvalue("nwp")
cpp=req.getvalue("cpp")

con=pymysql.connect(host='b9oxiichqfr42xvylzpl-mysql.services.clever-cloud.com',user='u5qyaqclnb8ayqg2',password='2vM1k3YsOaZaymOZs6hT',database='b9oxiichqfr42xvylzpl')
curs=con.cursor()

if nwp==cpp:
    curs.execute("select * from users where userid='%s' and password='%s'" %(id,cur))
    data=curs.fetchone()
    if data:
        curs.execute("update users set password='%s' where userid='%s'" %(nwp,id))
        con.commit()
        print("Password Changed Successfully..")
    else:
        print("Sorry password Cant Changed..")
else:
    print("New password Mismatched..")

print("<br> <br>")
print("<a href=change.html>Refresh..</a>")