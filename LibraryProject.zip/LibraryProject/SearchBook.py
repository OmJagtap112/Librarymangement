#!C:\Users\DELL\AppData\Local\Programs\Python\Python310\python
import cgi
import pymysql

print("Content-type:text/html")
print() 

print("<link rel='stylesheet' href='bootstrap.min.css'")
print("<div class='container'>")
req=cgi.FieldStorage()
bno=int(req.getvalue("bno"))

con=pymysql.connect(host='b9oxiichqfr42xvylzpl-mysql.services.clever-cloud.com',user='u5qyaqclnb8ayqg2',password='2vM1k3YsOaZaymOZs6hT',database='b9oxiichqfr42xvylzpl')
curs=con.cursor()

try:
    curs.execute("select * from Books where Bookcode=%d" %bno)
    data=curs.fetchone()
    print("<h3>")
    print("Name : ",data[1],"::","Price : ",data[3])
    print("</h3>")
except Exception as e:
    #print(e)
    print("Book Not Found...")

con.close()
print('<hr>') 

print("<br><a href='Admin.html'>Home..</a>")

print("</div>")