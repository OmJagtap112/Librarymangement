#!C:\Users\DELL\AppData\Local\Programs\Python\Python310\python
#import cgi
import pymysql

print("Content-type:text/html")
print()
print("<link rel='stylesheet' href='bootstrap.min.css'>")
print("<div class='container'><br>")
con=pymysql.connect(host='b9oxiichqfr42xvylzpl-mysql.services.clever-cloud.com',user='u5qyaqclnb8ayqg2',password='2vM1k3YsOaZaymOZs6hT',database='b9oxiichqfr42xvylzpl')
curs=con.cursor()

curs.execute("select * from Books")
data=curs.fetchall()
print("<h2 class='display-5'> Books Report</h2><hr>")

print("<table class='table table-bordered table-hover'>")
print("<tr style='background-color:azure'>")
print("<th>Bookcode")  
print("<th>BookName")
print("<th>Author")
print("<th>price")
print("<th>genre")
print("</tr>")

for rec in data:
    print("<tr>")
    print("<td>%d" %rec[0])
    print("<td>%s" %rec[1])
    print("<td>%s" %rec[2])
    print("<td>%.2f" %rec[3])
    print("<td>%s" %rec[4])
    print("</tr>")

con.close()
print("</table>")
print("</div>")