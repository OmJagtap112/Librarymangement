#!C:\Users\DELL\AppData\Local\Programs\Python\Python310\python
import cgi
import pymysql

print("Content-type:text/html")
print()

req=cgi.FieldStorage()
id=req.getvalue("uid")
#print(id)
con=pymysql.connect(host='b9oxiichqfr42xvylzpl-mysql.services.clever-cloud.com',user='u5qyaqclnb8ayqg2',password='2vM1k3YsOaZaymOZs6hT',database='b9oxiichqfr42xvylzpl')
curs=con.cursor()

curs.execute("select * from users where userid='%s'" %id)
data=curs.fetchone()

if data:
    print("<span style='color:red'>Sorry UserID %s already taken</span>" %id)
else:
    print("<span style='color:green'>Congrats UserID %s is available</span>" %id)

con.close()
