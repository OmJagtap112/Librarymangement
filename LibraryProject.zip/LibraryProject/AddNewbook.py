#!C:\Users\DELL\AppData\Local\Programs\Python\Python310\python
import cgi
import pymysql

print("Content-type:text/html")
print()

req=cgi.FieldStorage()
ano=int(req.getvalue("bno"))
anm=req.getvalue("bnm")
aut=req.getvalue("aut")
bal=float(req.getvalue("pc"))
atyp=req.getvalue("btyp")


con=pymysql.connect(host='b9oxiichqfr42xvylzpl-mysql.services.clever-cloud.com',user='u5qyaqclnb8ayqg2',password='2vM1k3YsOaZaymOZs6hT',database='b9oxiichqfr42xvylzpl')
curs=con.cursor()

try:
    curs.execute("insert into Books values(%d,'%s','%s',%.2f,'%s')"%(ano,anm,aut,bal,atyp))
    con.commit()
    print("<h2>Book Inserted Successfully...</h2>")
except Exception as e:
    print("Error : ",e) 

con.close()
print('<hr>')

print("<br><a href='Admin.html'>Refresh..</a>")