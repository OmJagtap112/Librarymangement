#!C:\Users\DELL\AppData\Local\Programs\Python\Python310\python
import cgi
import pymysql

print("Content-type:text/html")
print()

req=cgi.FieldStorage()
id=req.getvalue("uid")
pas=req.getvalue("psw")

#print(id+ pas)
con=pymysql.connect(host='b9oxiichqfr42xvylzpl-mysql.services.clever-cloud.com',user='u5qyaqclnb8ayqg2',password='2vM1k3YsOaZaymOZs6hT',database='b9oxiichqfr42xvylzpl')
curs=con.cursor()

curs.execute("select * from users where Userid='%s'"%id)
data=curs.fetchone()
#print(data)
if data:
    #print("Welcome '%s' In Server side Python"%id)
    print("<html>")
    print('<head>')
    print("<meta http-equiv='refresh' content='0;url=Admin.html'>")
    print('</head>')
    print("</html>")
else:
    #print("soory '%s' Please Registered First" %id)
    print('<html>')
    print('<head>')
    print("<meta http-equiv='refresh' content='0;url=Error.html'>")
    print('</head>')
    print('</html>')
con.close()